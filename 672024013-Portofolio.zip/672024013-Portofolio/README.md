# Portofolio
Ini adalah Portofolio Raphael Abraham, Keahlian juga minat saya

# Struktur
- index.html — Beranda
- about.html — Tentang Saya
- projects.html — Daftar proyek
- assets/
  - images/ 
- css/styles.css
- js/scripts.js
- README.md

# Cara menjalankan
Buka `index.html` di browser (cukup klik kanan pilih Open with live server)
